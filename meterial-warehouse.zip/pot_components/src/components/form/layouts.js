const LAYOUTS = {
  STANDARD: 'standard',
  CLASSIC: 'classic',
  FRESH: 'fresh'
}

export default LAYOUTS
