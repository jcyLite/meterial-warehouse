import createAPI from '../../common/helpers/create-api'

export default createAPI
