import BScroll from 'better-scroll'

export default BScroll
