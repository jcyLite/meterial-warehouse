import Loading from '../../components/loading/loading.vue'

Loading.install = function (Vue) {
  Vue.component(Loading.name, Loading)
}

export default Loading
