import '../../common/stylus/index.styl'

export default {
  install() {}
}
