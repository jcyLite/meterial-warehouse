<template>
  <footer class="s-footer">
    <a href="https://github.com/didi">© 2012-2018 DiDiChuxing. All Rights Reserved.</a>
  </footer>
</template>

<script>
export default {}
</script>

<style lang="stylus">
  .s-footer
    width: 100%
    padding-top: 60px
    padding-bottom: 20px
    text-align: center
    font-size: 14px
    a
      color: #4B4B4C
</style>
