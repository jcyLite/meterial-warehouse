import Bscroll from './Bscroll/Bscroll.vue';
import Scroll_Nav from './Scroll_Nav/Scroll_Nav.vue';
export default{
	Bscroll,Scroll_Nav
}
