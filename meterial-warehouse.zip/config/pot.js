process.env.NODE_ENV='development';
const developBase=require('./development.base.js');
new developBase('pot_components/example')
new developBase('pot_components/document');
