import Wrapper from './Wrapper/index.vue'
import SwipeCell from './SwipeCell/index.vue'
import Switch from './Switch/index.vue'
export {Wrapper,SwipeCell,Switch}