import KeyBoard from './src/keyboard.vue';
export {KeyBoard};
