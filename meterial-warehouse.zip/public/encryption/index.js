import {encryptByDES,decryptByDES} from '%/encryption/des.js';
export {encryptByDES,decryptByDES}
